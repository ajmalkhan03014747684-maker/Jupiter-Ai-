"""User settings (never contains API keys)."""
import json
from dataclasses import dataclass, asdict, fields
from pathlib import Path

from .paths import data_dir

MODE_OFFLINE = "offline"
MODE_CLOUD = "cloud"


@dataclass
class Settings:
    mode: str = MODE_OFFLINE
    provider: str = "anthropic"          # "anthropic" | "openai" (OpenAI-compatible)
    cloud_model: str = "claude-sonnet-5-5"
    openai_base_url: str = "https://api.openai.com/v1"
    anthropic_base_url: str = "https://api.anthropic.com"
    local_model_path: str = ""
    n_ctx: int = 2048
    max_tokens: int = 512
    temperature: float = 0.7
    fallback_to_offline: bool = True
    custom_system_prompt: str = ""

    def validate(self) -> "Settings":
        if self.mode not in (MODE_OFFLINE, MODE_CLOUD):
            self.mode = MODE_OFFLINE
        if self.provider not in ("anthropic", "openai"):
            self.provider = "anthropic"
        self.max_tokens = max(16, min(int(self.max_tokens), 8192))
        self.n_ctx = max(512, min(int(self.n_ctx), 32768))
        self.temperature = max(0.0, min(float(self.temperature), 2.0))
        return self


class SettingsStore:
    def __init__(self, directory=None):
        self._path = Path(directory or data_dir()) / "settings.json"

    def load(self) -> Settings:
        try:
            raw = json.loads(self._path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return Settings()
        names = {f.name for f in fields(Settings)}
        try:
            return Settings(**{k: v for k, v in raw.items() if k in names}).validate()
        except (TypeError, ValueError):
            return Settings()

    def save(self, settings: Settings) -> None:
        settings.validate()
        tmp = self._path.with_suffix(".tmp")
        tmp.write_text(json.dumps(asdict(settings), indent=2), encoding="utf-8")
        tmp.replace(self._path)
