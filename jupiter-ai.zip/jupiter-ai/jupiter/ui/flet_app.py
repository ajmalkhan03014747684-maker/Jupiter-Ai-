"""Flet UI. NOT covered by the automated tests (needs a Flutter/Flet runtime).

Kept deliberately plain (few control types, positional text args) to survive
Flet API differences between versions. If a control misbehaves on your
Flet version, the error will be in the build/run log - report it.
"""
import threading
import time

import flet as ft

from ..assistant import Assistant
from ..engines.local import find_backend_class
from ..errors import JupiterError
from ..history import History
from ..keystore import KeyStore
from ..model_manager import CATALOG, download, installed_path
from ..models import ChatMessage, GenSettings
from ..redact import redact
from ..settings import MODE_CLOUD, MODE_OFFLINE, SettingsStore
from .. import __version__

Button = getattr(ft, "Button", None) or ft.ElevatedButton
COL = getattr(ft, "Colors", None) or ft.colors
ICONS = getattr(ft, "Icons", None) or ft.icons


def main(page: ft.Page):
    page.title = "Jupiter AI"
    page.padding = 8

    settings_store, keystore, history = SettingsStore(), KeyStore(), History()
    assistant = Assistant(history, settings_store, keystore)
    state = {"conv": history.new_conversation(), "busy": False, "cancel": None}

    # ------------------------------------------------------------ chat view
    chat_list = ft.ListView(expand=True, spacing=8, auto_scroll=True)
    status = ft.Text("", size=12)
    mode_label = ft.Text("", size=12)
    box = ft.TextField(hint_text="Message Jupiter...", multiline=True,
                       min_lines=1, max_lines=4, expand=True)
    send_btn = ft.IconButton(icon=ICONS.SEND)
    stop_btn = ft.IconButton(icon=ICONS.STOP, visible=False)

    def bubble(text, mine):
        t = ft.Text(text, selectable=True)
        c = ft.Container(t, padding=10, border_radius=12,
                         bgcolor=COL.BLUE_100 if mine else COL.GREY_200)
        chat_list.controls.append(c)
        return t

    def refresh_mode():
        s = settings_store.load()
        mode_label.value = ("Mode: OFFLINE (on-device)" if s.mode == MODE_OFFLINE
                            else "Mode: CLOUD (%s, your key)" % s.provider)

    def set_busy(b):
        state["busy"] = b
        send_btn.visible, stop_btn.visible = (not b), b
        page.update()

    def do_send(_=None):
        text = (box.value or "").strip()
        if not text or state["busy"]:
            return
        box.value = ""
        bubble(text, True)
        out = bubble("...", False)
        cancel = threading.Event()
        state["cancel"] = cancel
        set_busy(True)
        first = {"v": True}

        def on_token(piece):
            if first["v"]:
                out.value, first["v"] = "", False
            out.value += piece
            out.update()

        def work():
            try:
                r = assistant.reply(state["conv"], text, on_token, cancel)
                if first["v"]:
                    out.value = r.text or "(no output)"
                if r.note:
                    status.value = r.note
            except JupiterError as exc:
                out.value = "Error: " + redact(exc)
            except Exception as exc:  # keep the UI alive; show a safe message
                out.value = "Unexpected error: " + redact(exc)
            finally:
                refresh_mode()
                set_busy(False)

        threading.Thread(target=work, daemon=True).start()

    def do_stop(_=None):
        if state["cancel"]:
            state["cancel"].set()

    def new_chat(_=None):
        state["conv"] = history.new_conversation()
        chat_list.controls.clear()
        status.value = ""
        page.update()

    send_btn.on_click, stop_btn.on_click, box.on_submit = do_send, do_stop, do_send

    # -------------------------------------------------------- settings view
    s0 = settings_store.load()
    mode_switch = ft.Switch(label="Use cloud API (needs your own key). Off = fully offline.",
                            value=(s0.mode == MODE_CLOUD))
    provider = {"v": s0.provider}
    prov_text = ft.Text("Provider: " + s0.provider)
    model_field = ft.TextField(label="Cloud model name", value=s0.cloud_model)
    base_field = ft.TextField(label="Base URL (OpenAI-compatible only)", value=s0.openai_base_url)
    key_field = ft.TextField(label="API key (stored only on this phone)", password=True,
                             can_reveal_password=True)
    key_status = ft.Text("", size=12)
    fallback = ft.Switch(label="If cloud fails, answer with offline model", value=s0.fallback_to_offline)
    note = ft.Text("", size=12)

    def refresh_key_status():
        key_status.value = "Key for %s: %s" % (provider["v"], keystore.masked(provider["v"]))

    def pick(p):
        def _h(_):
            provider["v"] = p
            prov_text.value = "Provider: " + p
            if p == "anthropic" and not model_field.value:
                model_field.value = "claude-sonnet-5-5"
            refresh_key_status()
            page.update()
        return _h

    def save_settings(_=None):
        s = settings_store.load()
        s.mode = MODE_CLOUD if mode_switch.value else MODE_OFFLINE
        s.provider = provider["v"]
        s.cloud_model = (model_field.value or "").strip()
        if provider["v"] == "openai":
            s.openai_base_url = (base_field.value or "").strip() or s.openai_base_url
        s.fallback_to_offline = bool(fallback.value)
        settings_store.save(s)
        if (key_field.value or "").strip():
            try:
                keystore.set(provider["v"], key_field.value)
            except ValueError as exc:
                note.value = str(exc)
                page.update()
                return
            key_field.value = ""
        refresh_key_status()
        refresh_mode()
        note.value = "Saved."
        page.update()

    def delete_key(_):
        keystore.delete(provider["v"])
        refresh_key_status()
        page.update()

    # local model section
    chosen = {"spec": CATALOG[0]}
    model_text = ft.Text("")
    progress = ft.ProgressBar(value=0, visible=False)
    dl_status = ft.Text("", size=12)
    dl_cancel = {"ev": None}

    def refresh_model():
        sp = chosen["spec"]
        model_text.value = "%s\n%s" % (sp.label, "INSTALLED" if installed_path(sp)
                                       else "not downloaded (~%d MB)" % sp.approx_mb)

    def pick_model(sp):
        def _h(_):
            chosen["spec"] = sp
            refresh_model()
            page.update()
        return _h

    def do_download(_):
        sp = chosen["spec"]
        ev = threading.Event()
        dl_cancel["ev"] = ev
        progress.visible, progress.value = True, None
        dl_status.value = "Downloading... (needs internet once; resumable)"
        page.update()

        def prog(done, total):
            if total:
                progress.value = done / total
                dl_status.value = "%d / %d MB" % (done >> 20, total >> 20)
                page.update()

        def work():
            try:
                p = download(sp, on_progress=prog, cancel=ev)
                s = settings_store.load()
                s.local_model_path = str(p)
                settings_store.save(s)
                dl_status.value = "Done."
            except JupiterError as exc:
                dl_status.value = redact(exc)
            progress.visible = False
            refresh_model()
            page.update()

        threading.Thread(target=work, daemon=True).start()

    def cancel_download(_):
        if dl_cancel["ev"]:
            dl_cancel["ev"].set()

    def self_test(_):
        dl_status.value = "Running offline self-test (first load can take a while)..."
        page.update()

        def work():
            t0 = time.time()
            try:
                backend, _cls = find_backend_class()
                s = settings_store.load()
                eng = assistant._local_engine(s)
                gen = GenSettings(max_tokens=40, temperature=0.2,
                                  system_prompt="Answer in one short sentence.")
                text = eng.generate([ChatMessage("user", "What is 2+2?")], gen)
                dl_status.value = "OK via %s in %.1fs: %s" % (backend, time.time() - t0, text.strip()[:200])
            except Exception as exc:
                dl_status.value = "SELF-TEST FAILED: " + redact(exc)
            page.update()

        threading.Thread(target=work, daemon=True).start()

    def delete_chats(_):
        history.clear_all()
        state["conv"] = history.new_conversation()
        chat_list.controls.clear()
        note.value = "All chats deleted."
        page.update()

    settings_view = ft.Column(
        visible=False, expand=True, scroll="auto",
        controls=[
            ft.Text("Offline model (works with no key, no internet)", weight="bold"),
            model_text,
            ft.Row([Button("Qwen 0.5B", on_click=pick_model(CATALOG[0])),
                    Button("Qwen 1.5B", on_click=pick_model(CATALOG[1]))], wrap=True),
            ft.Row([Button("Download", on_click=do_download),
                    Button("Cancel", on_click=cancel_download),
                    Button("Self-test", on_click=self_test)], wrap=True),
            progress, dl_status,
            ft.Divider(),
            ft.Text("Optional cloud mode (your own key)", weight="bold"),
            mode_switch, prov_text,
            ft.Row([Button("Anthropic", on_click=pick("anthropic")),
                    Button("OpenAI-compatible", on_click=pick("openai"))], wrap=True),
            model_field, base_field, key_field, key_status,
            ft.Row([Button("Delete key", on_click=delete_key)]),
            fallback,
            Button("Save settings", on_click=save_settings),
            note,
            ft.Divider(),
            Button("Delete all chats", on_click=delete_chats),
            ft.Text("Jupiter AI v%s. Chats and keys stay on this device. Cloud mode sends "
                    "your messages to the provider you choose." % __version__, size=11),
        ],
    )

    chat_view = ft.Column(
        expand=True,
        controls=[chat_list, status, ft.Row([box, send_btn, stop_btn])],
    )

    def show(settings):
        settings_view.visible, chat_view.visible = settings, not settings
        page.update()

    top = ft.Row([ft.Text("Jupiter AI", size=20, weight="bold"),
                  ft.IconButton(icon=ICONS.ADD, on_click=new_chat),
                  ft.IconButton(icon=ICONS.SETTINGS, on_click=lambda _: show(True)),
                  ft.IconButton(icon=ICONS.CHAT, on_click=lambda _: show(False))])

    body = ft.Column([top, mode_label, chat_view, settings_view], expand=True)
    safe = getattr(ft, "SafeArea", None)
    page.add(safe(body, expand=True) if safe else body)

    refresh_mode(); refresh_key_status(); refresh_model()
    bubble("Hi, I'm Jupiter. Open Settings (gear) to download the offline model "
           "if you have not yet.", False)
    page.update()
