"""Storage for users' own API keys.

Rules:
- Keys are typed into the app by the user. They are never in the repo.
- Stored only in app-private storage (keys.json, chmod 600 where supported).
  This relies on Android's per-app sandbox; it is NOT hardware-backed encryption.
- Environment variables JUPITER_<PROVIDER>_API_KEY override the file (for
  desktop/CI use).
- Offline mode never reads this store.
"""
import json
import os
from pathlib import Path

from .paths import data_dir

PROVIDERS = ("anthropic", "openai")


def _env_name(provider: str) -> str:
    return "JUPITER_%s_API_KEY" % provider.upper()


class KeyStore:
    def __init__(self, directory=None):
        self._path = Path(directory or data_dir()) / "keys.json"

    def _load(self) -> dict:
        try:
            return json.loads(self._path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return {}

    def _write(self, data: dict) -> None:
        tmp = self._path.with_suffix(".tmp")
        fd = os.open(str(tmp), os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            json.dump(data, fh)
        try:
            os.chmod(str(tmp), 0o600)
        except OSError:
            pass
        os.replace(str(tmp), str(self._path))

    def get(self, provider: str):
        env = os.environ.get(_env_name(provider))
        if env:
            return env.strip()
        key = self._load().get(provider)
        return key.strip() if isinstance(key, str) and key.strip() else None

    def set(self, provider: str, key: str) -> None:
        if provider not in PROVIDERS:
            raise ValueError("unknown provider")
        key = (key or "").strip()
        if not key:
            raise ValueError("empty key")
        data = self._load()
        data[provider] = key
        self._write(data)

    def delete(self, provider: str) -> None:
        data = self._load()
        if provider in data:
            del data[provider]
            self._write(data)

    def has(self, provider: str) -> bool:
        return self.get(provider) is not None

    def masked(self, provider: str) -> str:
        key = self.get(provider)
        if not key:
            return "(not set)"
        return "..." + key[-4:] if len(key) > 8 else "(set)"
