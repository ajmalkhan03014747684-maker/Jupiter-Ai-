"""Local chat history in SQLite (on-device only)."""
import sqlite3
import time
from pathlib import Path
from typing import List

from .models import ChatMessage
from .paths import data_dir


class History:
    def __init__(self, directory=None, filename="history.db"):
        self._db = str(Path(directory or data_dir()) / filename)
        with self._conn() as c:
            c.executescript(
                """
                CREATE TABLE IF NOT EXISTS conversations(
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    title TEXT NOT NULL,
                    created REAL NOT NULL);
                CREATE TABLE IF NOT EXISTS messages(
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    conversation_id INTEGER NOT NULL
                        REFERENCES conversations(id) ON DELETE CASCADE,
                    role TEXT NOT NULL,
                    content TEXT NOT NULL,
                    ts REAL NOT NULL);
                """
            )

    def _conn(self):
        conn = sqlite3.connect(self._db)
        conn.execute("PRAGMA foreign_keys = ON")
        return conn

    def new_conversation(self, title="New chat") -> int:
        with self._conn() as c:
            cur = c.execute(
                "INSERT INTO conversations(title, created) VALUES (?, ?)",
                (title[:80], time.time()),
            )
            return cur.lastrowid

    def rename(self, conversation_id: int, title: str) -> None:
        with self._conn() as c:
            c.execute("UPDATE conversations SET title=? WHERE id=?", (title[:80], conversation_id))

    def add(self, conversation_id: int, role: str, content: str) -> None:
        with self._conn() as c:
            c.execute(
                "INSERT INTO messages(conversation_id, role, content, ts) VALUES (?,?,?,?)",
                (conversation_id, role, content, time.time()),
            )

    def messages(self, conversation_id: int) -> List[ChatMessage]:
        with self._conn() as c:
            rows = c.execute(
                "SELECT role, content, ts FROM messages WHERE conversation_id=? ORDER BY id",
                (conversation_id,),
            ).fetchall()
        return [ChatMessage(r, t, ts) for r, t, ts in rows]

    def conversations(self):
        with self._conn() as c:
            return c.execute(
                "SELECT id, title, created FROM conversations ORDER BY id DESC"
            ).fetchall()

    def delete_conversation(self, conversation_id: int) -> None:
        with self._conn() as c:
            c.execute("DELETE FROM conversations WHERE id=?", (conversation_id,))

    def clear_all(self) -> None:
        with self._conn() as c:
            c.execute("DELETE FROM messages")
            c.execute("DELETE FROM conversations")

    def export_markdown(self, conversation_id: int) -> str:
        lines = []
        for m in self.messages(conversation_id):
            who = "You" if m.role == "user" else "Jupiter"
            lines.append("**%s:**\n\n%s\n" % (who, m.content))
        return "\n".join(lines)
