"""Jupiter AI: offline-first assistant core (UI-independent, pure Python)."""

__version__ = "0.1.0"
