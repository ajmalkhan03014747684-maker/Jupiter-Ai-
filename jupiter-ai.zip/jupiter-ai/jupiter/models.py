from dataclasses import dataclass, field
import time


@dataclass
class ChatMessage:
    role: str  # "system" | "user" | "assistant"
    content: str
    timestamp: float = field(default_factory=time.time)

    def as_dict(self):
        return {"role": self.role, "content": self.content}


@dataclass
class GenSettings:
    max_tokens: int = 512
    temperature: float = 0.7
    system_prompt: str = ""
