"""Keep prompts inside the model's context window (rough, character-based)."""
from typing import List

from .models import ChatMessage


def trim_messages(messages: List[ChatMessage], max_chars: int) -> List[ChatMessage]:
    """Keep the newest messages whose total length fits max_chars.

    The newest message is always kept (truncated from the left if it alone is
    too long) so the model always sees the question being asked.
    """
    if not messages:
        return []
    kept: List[ChatMessage] = []
    total = 0
    for m in reversed(messages):
        size = len(m.content)
        if kept and total + size > max_chars:
            break
        kept.append(m)
        total += size
    kept.reverse()
    last = kept[-1]
    if len(last.content) > max_chars:
        kept[-1] = ChatMessage(last.role, last.content[-max_chars:], last.timestamp)
    # Drop a leading assistant message so the turn order stays valid.
    while len(kept) > 1 and kept[0].role == "assistant":
        kept.pop(0)
    return kept


def chars_budget(n_ctx: int, max_tokens: int) -> int:
    """~3 chars per token is a conservative estimate for English/code."""
    return max(512, (n_ctx - max_tokens) * 3 - 600)
