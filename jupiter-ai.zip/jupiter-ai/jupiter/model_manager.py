"""Download and validate local GGUF models (one-time download, then offline)."""
import hashlib
import os
import threading
import urllib.error
import urllib.request
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Optional

from .engines.cloud import _ssl_context, check_url
from .errors import Cancelled, DownloadError
from .paths import models_dir


@dataclass(frozen=True)
class ModelSpec:
    id: str
    label: str
    url: str
    filename: str
    approx_mb: int
    license: str
    min_bytes: int
    sha256: Optional[str] = None  # set once you have verified a hash yourself


CATALOG = [
    ModelSpec(
        id="qwen2.5-0.5b",
        label="Qwen2.5 0.5B Instruct (Q4_K_M) - small, fast, recommended first",
        url="https://huggingface.co/Qwen/Qwen2.5-0.5B-Instruct-GGUF/resolve/main/qwen2.5-0.5b-instruct-q4_k_m.gguf",
        filename="qwen2.5-0.5b-instruct-q4_k_m.gguf",
        approx_mb=490,
        license="Apache-2.0 (check the model card)",
        min_bytes=100 * 1024 * 1024,
    ),
    ModelSpec(
        id="qwen2.5-1.5b",
        label="Qwen2.5 1.5B Instruct (Q4_K_M) - better answers, slower, more RAM",
        url="https://huggingface.co/Qwen/Qwen2.5-1.5B-Instruct-GGUF/resolve/main/qwen2.5-1.5b-instruct-q4_k_m.gguf",
        filename="qwen2.5-1.5b-instruct-q4_k_m.gguf",
        approx_mb=1100,
        license="Apache-2.0 (check the model card)",
        min_bytes=400 * 1024 * 1024,
    ),
]


def get_spec(model_id: str) -> ModelSpec:
    for s in CATALOG:
        if s.id == model_id:
            return s
    raise KeyError(model_id)


def is_valid_gguf(path, min_bytes: int = 1024) -> bool:
    try:
        if os.path.getsize(path) < min_bytes:
            return False
        with open(path, "rb") as fh:
            return fh.read(4) == b"GGUF"
    except OSError:
        return False


def _sha256(path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for block in iter(lambda: fh.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def installed_path(spec: ModelSpec, directory=None) -> Optional[Path]:
    p = Path(directory or models_dir()) / spec.filename
    return p if is_valid_gguf(p, spec.min_bytes) else None


ProgressCb = Callable[[int, int], None]  # (bytes_done, bytes_total or 0)


def download(
    spec: ModelSpec,
    directory=None,
    on_progress: Optional[ProgressCb] = None,
    cancel: Optional[threading.Event] = None,
    timeout: int = 30,
) -> Path:
    """Download spec to directory, resuming a partial file if one exists."""
    check_url(spec.url)
    dest_dir = Path(directory or models_dir())
    dest_dir.mkdir(parents=True, exist_ok=True)
    final = dest_dir / spec.filename
    part = dest_dir / (spec.filename + ".part")

    if is_valid_gguf(final, spec.min_bytes):
        return final

    done = part.stat().st_size if part.exists() else 0
    headers = {"User-Agent": "JupiterAI/0.1"}
    if done:
        headers["Range"] = "bytes=%d-" % done
    req = urllib.request.Request(spec.url, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=timeout, context=_ssl_context()) as resp:
            status = getattr(resp, "status", 200)
            length = int(resp.headers.get("Content-Length") or 0)
            if done and status == 206:
                mode, total = "ab", done + length
            else:  # fresh download, or server ignored Range
                mode, done, total = "wb", 0, length
            with open(part, mode) as out:
                while True:
                    if cancel is not None and cancel.is_set():
                        raise Cancelled("Download cancelled (partial file kept for resume).")
                    block = resp.read(1 << 16)
                    if not block:
                        break
                    out.write(block)
                    done += len(block)
                    if on_progress:
                        on_progress(done, total)
    except urllib.error.HTTPError as exc:
        if exc.code == 416 and part.exists() and is_valid_gguf(part, spec.min_bytes):
            pass  # already complete
        else:
            raise DownloadError("Download failed: HTTP %d" % exc.code)
    except (urllib.error.URLError, OSError) as exc:
        raise DownloadError("Download failed: %s (run again to resume)" % exc)

    if not is_valid_gguf(part, spec.min_bytes):
        raise DownloadError("Downloaded file is not a valid GGUF model (too small or wrong format).")
    if spec.sha256 and _sha256(part) != spec.sha256.lower():
        part.unlink()
        raise DownloadError("Checksum mismatch; the file was deleted.")
    os.replace(str(part), str(final))
    return final
