"""Offline engine: runs a local GGUF model through llama.cpp bindings.

Backends tried in order: ``pylolm`` (Android arm64 wheel; used by the Flet
build) then ``llama_cpp`` (llama-cpp-python, desktop/CI). Both expose a
llama-cpp-python-style ``Llama`` class. No network and no API key is used.
"""
import importlib
import os
import threading
from typing import List, Optional

from ..errors import EngineUnavailableError
from ..models import ChatMessage, GenSettings
from .base import Engine, TokenCallback, with_system

BACKEND_MODULES = ("pylolm", "llama_cpp")


def find_backend_class():
    """Return (module_name, Llama class) for the first importable backend."""
    errors = []
    for name in BACKEND_MODULES:
        try:
            mod = importlib.import_module(name)
            return name, getattr(mod, "Llama")
        except Exception as exc:  # ImportError, or native load failure
            errors.append("%s: %s" % (name, exc))
    raise EngineUnavailableError(
        "No local inference backend could be imported (" + "; ".join(errors) + ")."
    )


def extract_piece(chunk) -> str:
    """Pull the text out of one streamed chunk (chat or completion style)."""
    try:
        choice = chunk["choices"][0]
    except (KeyError, IndexError, TypeError):
        return ""
    delta = choice.get("delta")
    if isinstance(delta, dict):
        return delta.get("content") or ""
    return choice.get("text") or ""


class LocalEngine(Engine):
    name = "local"

    def __init__(self, model_path: str, n_ctx: int = 2048, backend_cls=None):
        self.model_path = model_path
        self.n_ctx = n_ctx
        self._backend_cls = backend_cls
        self.backend_name = "injected" if backend_cls else None
        self._llm = None
        self._lock = threading.Lock()

    def load(self) -> None:
        if self._llm is not None:
            return
        if not self.model_path or not os.path.isfile(self.model_path):
            raise EngineUnavailableError(
                "No local model file found. Download one in Settings first."
            )
        if self._backend_cls is None:
            self.backend_name, self._backend_cls = find_backend_class()
        try:
            self._llm = self._backend_cls(self.model_path, n_ctx=self.n_ctx)
        except Exception as exc:
            raise EngineUnavailableError("Model failed to load: %s" % exc)

    def unload(self) -> None:
        llm, self._llm = self._llm, None
        close = getattr(llm, "close", None)
        if callable(close):
            close()

    def generate(
        self,
        messages: List[ChatMessage],
        gen: GenSettings,
        on_token: Optional[TokenCallback] = None,
        cancel: Optional[threading.Event] = None,
    ) -> str:
        self.load()
        parts: List[str] = []
        with self._lock:
            stream = self._llm.create_chat_completion(
                messages=with_system(messages, gen),
                max_tokens=gen.max_tokens,
                temperature=gen.temperature,
                stream=True,
            )
            for chunk in stream:
                if cancel is not None and cancel.is_set():
                    break
                piece = extract_piece(chunk)
                if piece:
                    parts.append(piece)
                    if on_token:
                        on_token(piece)
        return "".join(parts)
