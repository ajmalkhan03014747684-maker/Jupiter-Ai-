import threading
from typing import Callable, List, Optional

from ..models import ChatMessage, GenSettings

TokenCallback = Callable[[str], None]


class Engine:
    name = "engine"

    def generate(
        self,
        messages: List[ChatMessage],
        gen: GenSettings,
        on_token: Optional[TokenCallback] = None,
        cancel: Optional[threading.Event] = None,
    ) -> str:
        """Return the full reply; call on_token with each text piece.

        Stops early (returning what was produced) if cancel is set.
        """
        raise NotImplementedError


def with_system(messages: List[ChatMessage], gen: GenSettings) -> List[dict]:
    out = []
    if gen.system_prompt:
        out.append({"role": "system", "content": gen.system_prompt})
    out.extend(m.as_dict() for m in messages if m.role in ("user", "assistant"))
    return out
