"""Optional cloud engine using the USER'S OWN API key.

Supports Anthropic's Messages API and OpenAI-compatible Chat Completions
endpoints (OpenAI, OpenRouter, Groq, local servers, ...). Uses only the
standard library (+ certifi if present for TLS roots on Android).

Safety:
- HTTPS is required, except for localhost (used by tests / local servers).
- The key is only sent in a request header to the configured host.
- Error text is redacted so a key can never reach the UI or logs.
"""
import json
import ssl
import threading
import urllib.error
import urllib.request
from typing import List, Optional
from urllib.parse import urlparse

from ..errors import CloudError, MissingKeyError
from ..models import ChatMessage, GenSettings
from ..redact import redact
from .base import Engine, TokenCallback, with_system

ANTHROPIC_VERSION = "2023-06-01"
LOCAL_HOSTS = ("localhost", "127.0.0.1", "::1")


def _ssl_context():
    try:
        import certifi

        return ssl.create_default_context(cafile=certifi.where())
    except Exception:
        return ssl.create_default_context()


def check_url(url: str) -> None:
    p = urlparse(url)
    if p.scheme == "https":
        return
    if p.scheme == "http" and p.hostname in LOCAL_HOSTS:
        return
    raise CloudError("Cloud URL must use https (http only for localhost).")


class CloudEngine(Engine):
    name = "cloud"

    def __init__(self, provider, model, api_key, base_url, timeout=60):
        self.provider = provider
        self.model = model
        self._key = api_key
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout

    # -- request building ------------------------------------------------
    def _request(self, messages, gen):
        if not self._key:
            raise MissingKeyError("No API key set for %s." % self.provider)
        if not self.model:
            raise CloudError("No cloud model name set in Settings.")
        history = [m for m in with_system(messages, gen) if m["role"] != "system"]
        if self.provider == "anthropic":
            url = self.base_url + "/v1/messages"
            headers = {"x-api-key": self._key, "anthropic-version": ANTHROPIC_VERSION}
            body = {
                "model": self.model,
                "max_tokens": gen.max_tokens,
                "temperature": min(gen.temperature, 1.0),
                "messages": history,
                "stream": True,
            }
            if gen.system_prompt:
                body["system"] = gen.system_prompt
        elif self.provider == "openai":
            url = self.base_url + "/chat/completions"
            headers = {"Authorization": "Bearer " + self._key}
            body = {
                "model": self.model,
                "max_tokens": gen.max_tokens,
                "temperature": gen.temperature,
                "messages": with_system(messages, gen),
                "stream": True,
            }
        else:
            raise CloudError("Unknown provider.")
        check_url(url)
        headers.update({"Content-Type": "application/json", "Accept": "text/event-stream"})
        data = json.dumps(body).encode("utf-8")
        return urllib.request.Request(url, data=data, headers=headers, method="POST")

    # -- stream parsing ----------------------------------------------------
    def _piece(self, payload: dict) -> str:
        if self.provider == "anthropic":
            if payload.get("type") == "content_block_delta":
                return (payload.get("delta") or {}).get("text") or ""
            if payload.get("type") == "error":
                raise CloudError(
                    redact((payload.get("error") or {}).get("message", "provider error"), [self._key])
                )
            return ""
        try:
            return payload["choices"][0]["delta"].get("content") or ""
        except (KeyError, IndexError, TypeError, AttributeError):
            return ""

    def generate(
        self,
        messages: List[ChatMessage],
        gen: GenSettings,
        on_token: Optional[TokenCallback] = None,
        cancel: Optional[threading.Event] = None,
    ) -> str:
        req = self._request(messages, gen)
        parts: List[str] = []
        try:
            with urllib.request.urlopen(req, timeout=self.timeout, context=_ssl_context()) as resp:
                for raw in resp:
                    if cancel is not None and cancel.is_set():
                        break
                    line = raw.decode("utf-8", "replace").strip()
                    if not line.startswith("data:"):
                        continue
                    data = line[5:].strip()
                    if data == "[DONE]":
                        break
                    try:
                        payload = json.loads(data)
                    except ValueError:
                        continue
                    piece = self._piece(payload)
                    if piece:
                        parts.append(piece)
                        if on_token:
                            on_token(piece)
        except urllib.error.HTTPError as exc:
            raise CloudError(self._http_message(exc))
        except (urllib.error.URLError, OSError) as exc:
            raise CloudError("Network error: %s" % redact(exc, [self._key]))
        return "".join(parts)

    def _http_message(self, exc) -> str:
        if exc.code in (401, 403):
            return "The provider rejected the API key (HTTP %d). Check it in Settings." % exc.code
        if exc.code == 429:
            return "Rate limit or quota reached (HTTP 429)."
        if exc.code == 404:
            return "Endpoint or model not found (HTTP 404). Check the model name."
        try:
            detail = exc.read().decode("utf-8", "replace")[:300]
        except Exception:
            detail = ""
        return "Provider error HTTP %d. %s" % (exc.code, redact(detail, [self._key]))
