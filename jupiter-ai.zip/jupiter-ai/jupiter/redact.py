"""Remove anything that looks like a secret from text before it is shown/logged."""
import re

_PATTERNS = [
    re.compile(r"sk-[A-Za-z0-9_\-]{8,}"),
    re.compile(r"(?i)bearer\s+[A-Za-z0-9._\-]{8,}"),
    re.compile(r"(?i)(x-api-key|api[_-]?key|authorization)\s*[:=]\s*\S+"),
    re.compile(r"AIza[0-9A-Za-z_\-]{20,}"),
    re.compile(r"gh[pousr]_[A-Za-z0-9]{20,}"),
]


def redact(text: str, known_secrets=()) -> str:
    out = str(text)
    for secret in known_secrets:
        if secret and len(secret) >= 4:
            out = out.replace(secret, "[REDACTED]")
    for pat in _PATTERNS:
        out = pat.sub("[REDACTED]", out)
    return out
