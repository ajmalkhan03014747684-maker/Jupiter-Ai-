"""Where Jupiter keeps its files. Always app-private storage, never the repo."""
import os
from pathlib import Path


def data_dir() -> Path:
    """Resolve the writable data directory.

    Order: JUPITER_DATA_DIR (tests / desktop), FLET_APP_STORAGE_DATA (Flet on
    Android), then ~/.jupiter_ai.
    """
    for var in ("JUPITER_DATA_DIR", "FLET_APP_STORAGE_DATA"):
        value = os.environ.get(var)
        if value:
            p = Path(value)
            break
    else:
        p = Path.home() / ".jupiter_ai"
    p.mkdir(parents=True, exist_ok=True)
    return p


def models_dir() -> Path:
    p = data_dir() / "models"
    p.mkdir(parents=True, exist_ok=True)
    return p
