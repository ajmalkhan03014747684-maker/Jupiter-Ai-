"""Ties settings, history, engines and keys together (no UI code)."""
import threading
from dataclasses import dataclass
from typing import Callable, Optional

from .context import chars_budget, trim_messages
from .engines.cloud import CloudEngine
from .engines.local import LocalEngine
from .errors import CloudError, EngineUnavailableError, MissingKeyError
from .history import History
from .keystore import KeyStore
from .model_manager import CATALOG, installed_path
from .models import GenSettings
from .prompts import SYSTEM_PROMPT
from .settings import MODE_CLOUD, Settings, SettingsStore


@dataclass
class Reply:
    text: str
    engine: str          # "local" | "cloud"
    note: str = ""       # shown to the user (e.g. fallback explanation)


class Assistant:
    def __init__(
        self,
        history: History,
        settings_store: SettingsStore,
        keystore: KeyStore,
        local_factory: Optional[Callable] = None,
        cloud_factory: Optional[Callable] = None,
    ):
        self.history = history
        self.settings_store = settings_store
        self.keystore = keystore
        self._local_factory = local_factory or (lambda path, n_ctx: LocalEngine(path, n_ctx))
        self._cloud_factory = cloud_factory or (
            lambda provider, model, key, base: CloudEngine(provider, model, key, base)
        )
        self._local = None
        self._local_key = None

    # -- helpers -----------------------------------------------------------
    def resolve_local_path(self, s: Settings) -> str:
        if s.local_model_path:
            return s.local_model_path
        for spec in CATALOG:
            p = installed_path(spec)
            if p:
                return str(p)
        return ""

    def _local_engine(self, s: Settings):
        path = self.resolve_local_path(s)
        key = (path, s.n_ctx)
        if self._local is None or self._local_key != key:
            if self._local is not None and hasattr(self._local, "unload"):
                self._local.unload()
            self._local = self._local_factory(path, s.n_ctx)
            self._local_key = key
        return self._local

    @staticmethod
    def _gen(s: Settings) -> GenSettings:
        return GenSettings(
            max_tokens=s.max_tokens,
            temperature=s.temperature,
            system_prompt=s.custom_system_prompt.strip() or SYSTEM_PROMPT,
        )

    # -- main entry --------------------------------------------------------
    def reply(
        self,
        conversation_id: int,
        user_text: str,
        on_token=None,
        cancel: Optional[threading.Event] = None,
    ) -> Reply:
        s = self.settings_store.load()
        first = not self.history.messages(conversation_id)
        self.history.add(conversation_id, "user", user_text)
        if first:
            self.history.rename(conversation_id, user_text.strip().splitlines()[0][:40] or "Chat")

        gen = self._gen(s)
        msgs = trim_messages(
            self.history.messages(conversation_id), chars_budget(s.n_ctx, s.max_tokens)
        )

        streamed = []

        def tap(piece):
            streamed.append(piece)
            if on_token:
                on_token(piece)

        note = ""
        engine_name = "local"
        text = None

        if s.mode == MODE_CLOUD:
            key = self.keystore.get(s.provider)
            base = s.anthropic_base_url if s.provider == "anthropic" else s.openai_base_url
            try:
                if not key:
                    raise MissingKeyError("No API key set for %s." % s.provider)
                engine = self._cloud_factory(s.provider, s.cloud_model, key, base)
                text = engine.generate(msgs, gen, tap, cancel)
                engine_name = "cloud"
            except (CloudError, MissingKeyError) as exc:
                if streamed:  # partial answer already shown: keep it, do not duplicate
                    text, engine_name = "".join(streamed), "cloud"
                    note = "Cloud request failed midway: %s" % exc
                elif s.fallback_to_offline:
                    note = "Cloud unavailable (%s) - answered with the offline model." % exc
                else:
                    raise

        if text is None:
            engine = self._local_engine(s)
            try:
                text = engine.generate(msgs, gen, tap, cancel)
            except EngineUnavailableError:
                raise
            engine_name = "local"

        if text.strip():
            self.history.add(conversation_id, "assistant", text)
        return Reply(text=text, engine=engine_name, note=note)
