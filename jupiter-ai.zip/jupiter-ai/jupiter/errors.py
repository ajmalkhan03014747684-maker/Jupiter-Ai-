class JupiterError(Exception):
    """Base class. Messages must never contain API keys."""


class MissingKeyError(JupiterError):
    pass


class EngineUnavailableError(JupiterError):
    pass


class CloudError(JupiterError):
    pass


class DownloadError(JupiterError):
    pass


class Cancelled(JupiterError):
    pass
