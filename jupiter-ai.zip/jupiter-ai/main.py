import flet as ft

from jupiter.ui.flet_app import main

ft.run(main)
