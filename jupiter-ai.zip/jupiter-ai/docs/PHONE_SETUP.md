# Phone-only setup

## 1. Get the files onto GitHub (Termux)

1. Install **Termux** from F-Droid (the Play Store build is outdated).
2. In a browser, create an empty GitHub repo (e.g. `jupiter-ai`; public repos get free Actions minutes).
3. Create a fine-grained token: GitHub -> Settings -> Developer settings -> Fine-grained tokens -> only that repo, permissions **Contents: read/write** and **Workflows: read/write**. Copy it once.
4. In Termux:
```
pkg install git unzip
termux-setup-storage
cd ~ && unzip ~/storage/downloads/jupiter-ai.zip && cd jupiter-ai
git init -b main
git config user.name "Your Name"
git config user.email "you@example.com"
git add . && git commit -m "Initial commit"
git remote add origin https://github.com/YOUR_USER/jupiter-ai.git
git push -u origin main
```
When asked for a password, paste the token (do not put it in the URL). Never commit the token.

(Alternative without Termux: open the repo in GitHub Codespaces from your phone browser, upload the zip, unzip in its terminal, commit.)

## 2. Build

- Repo -> **Actions** -> **Tests** must pass.
- **Build APK** -> *Run workflow*. First run is slow (Flutter + Android toolchain download).
- When green, open the run -> **Artifacts** -> `jupiter-ai-apk`. Unzip, tap the `.apk`, allow "install unknown apps" for your browser/files app.

## 3. If the build fails

Open the failed step, copy the last ~60 lines of the log and fix or send them for diagnosis. Likely first-build issues: Flet CLI flag changes (edit `build-apk.yml`), native wheel not found for the Android API level (pylolm wheels are `android_24_arm64_v8a`, so use an arm64 phone on Android 7+), or a Flet control API difference in `jupiter/ui/flet_app.py`.

## 4. Verify offline for real

Settings -> Download (Wi-Fi) -> **Self-test**. It must say `OK via pylolm` (or `llama_cpp`) with a sensible answer. Then enable airplane mode and chat.

## Optional: prove the model path on GitHub first

Actions -> **Real model smoke test** -> Run. Green means the model file, chat template and engine code produce text on Linux (not on Android).
