# Jupiter AI

A Python-first Android assistant. **Offline mode** runs a small open GGUF model
on the phone through llama.cpp: no account, no API key, no internet after the
one-time model download. **Cloud mode** is optional: users enter their *own*
key (Anthropic, or any OpenAI-compatible provider) for potentially stronger answers.

Built to be developed and built with **only an Android phone**: edit on GitHub,
build the APK with GitHub Actions (free for public repos), install the artifact.

## Honest status (v0.1.0)

| Part | Status |
|---|---|
| Core logic (settings, key store, history, context trimming, cloud streaming for both providers, model download/resume/validation, offline/cloud routing + fallback, secret hygiene) | **36 unit tests pass** (run with `python -m unittest`). Cloud and download tests use a local fake HTTP server, not real providers. |
| Local engine code path with a real GGUF model | **Not yet run.** Tested only with a fake backend. The `Real model smoke test` workflow runs it on Linux; the in-app **Self-test** runs it on your phone. |
| Android APK build (Flet + pylolm wheel) | **Not yet built.** Written from the Flet/pylolm docs; expect to iterate on the first build log. |
| Flet UI (`jupiter/ui/flet_app.py`) | **Not run.** Compiles, but no Flet runtime was available. |
| Cloud mode against real Anthropic/OpenAI endpoints | **Not tested with a real key.** Request shapes follow the public API docs. |

Do not treat "offline AI works on my phone" as true until the in-app Self-test says OK.

## Why Flet + pylolm (not Kivy)

`pylolm` publishes an Android arm64 wheel of llama.cpp and documents a working
`flet build apk` path; for Kivy/python-for-android it says a recipe is still on
its roadmap. So this repo uses Flet (Python UI, Flutter shell). The core
(`jupiter/`) has no UI imports, so the UI can be swapped later.

## Phone-only setup

See [docs/PHONE_SETUP.md](docs/PHONE_SETUP.md). Summary:
1. Put this repo on GitHub (Termux route in the doc).
2. Actions -> **Tests** should be green.
3. Actions -> **Build APK** -> Run workflow (about 15-40 min). Download the `jupiter-ai-apk` artifact, unzip, install the APK.
4. Open the app -> Settings -> Download model (about 490 MB, Wi-Fi) -> **Self-test**.
5. Switch Wi-Fi/data off and chat. That is the real offline test.

## Using your own API key (optional)

Settings -> turn on cloud -> choose provider -> enter model name -> paste key -> Save.
- Anthropic: default model name is `claude-sonnet-5-5`; edit it freely.
- OpenAI-compatible: set the model name and base URL (HTTPS required).
- If the cloud call fails (or no key), the app can fall back to the offline model; this is a setting.
- Offline mode never reads or needs a key.

## Security and privacy

- No keys in the repo; `.gitignore` blocks `keys.json`, `.env`, `*.gguf`; a test scans source for key patterns.
- Keys live in the app's private storage (`keys.json`, mode 600). That relies on Android's app sandbox; it is **not** hardware-backed encryption. A rooted phone or a backup can expose it. Delete the key in Settings any time.
- Keys are sent only in the request header to the configured HTTPS host. Error messages are redacted.
- Cloud mode sends your messages to that provider. Offline mode sends nothing anywhere; the only network use is the model download.

## Limits

- A 0.5B-1.5B model is weak at coding and reasoning, slow on older phones, and can be confidently wrong. It has no web access and cannot run code or edit files (the app does not pretend otherwise).
- Model files are hosted by Hugging Face under their own licenses; check them before redistributing the app.
- Model download URLs/sizes in `jupiter/model_manager.py` were not verified by download; a wrong URL shows a clear error.

## Layout

```
main.py                  Flet entry point
jupiter/                 core (tested) + ui/flet_app.py (untested)
  engines/local.py       llama.cpp backends (pylolm -> llama_cpp)
  engines/cloud.py       Anthropic + OpenAI-compatible streaming
tests/                   unittest suite (stdlib only)
scripts/smoke_local_model.py
.github/workflows/       tests, build-apk, smoke-real-model
```

## Develop

```
python -m unittest discover -s tests -t . -v      # or: pytest
python scripts/smoke_local_model.py /path/model.gguf
```
