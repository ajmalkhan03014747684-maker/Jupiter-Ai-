import json
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer


class FakeServer:
    """Tiny local HTTP server. `handler_fn(handler)` serves each request."""

    def __init__(self, handler_fn):
        outer = handler_fn

        class H(BaseHTTPRequestHandler):
            def do_POST(self):
                length = int(self.headers.get("Content-Length") or 0)
                self.body = json.loads(self.rfile.read(length) or b"{}")
                outer(self)

            def do_GET(self):
                outer(self)

            def log_message(self, *a):
                pass

        self.httpd = ThreadingHTTPServer(("127.0.0.1", 0), H)
        self.port = self.httpd.server_address[1]
        self.url = "http://127.0.0.1:%d" % self.port
        threading.Thread(target=self.httpd.serve_forever, daemon=True).start()

    def close(self):
        self.httpd.shutdown()
        self.httpd.server_close()


def sse(handler, lines):
    handler.send_response(200)
    handler.send_header("Content-Type", "text/event-stream")
    handler.end_headers()
    for ln in lines:
        handler.wfile.write((ln + "\n\n").encode())
        handler.wfile.flush()
