import json
import threading
import unittest

from jupiter.engines.cloud import CloudEngine, check_url
from jupiter.engines.local import LocalEngine, extract_piece
from jupiter.errors import CloudError, EngineUnavailableError, MissingKeyError
from jupiter.models import ChatMessage, GenSettings

from .helpers import FakeServer, sse

MSGS = [ChatMessage("user", "hello")]
GEN = GenSettings(max_tokens=50, temperature=0.5, system_prompt="be nice")


class CloudTests(unittest.TestCase):
    def test_openai_stream_and_request_shape(self):
        seen = {}

        def h(req):
            seen["auth"] = req.headers["Authorization"]
            seen["body"] = req.body
            sse(req, ['data: ' + json.dumps({"choices": [{"delta": {"content": "Hel"}}]}),
                      'data: ' + json.dumps({"choices": [{"delta": {"content": "lo"}}]}),
                      "data: [DONE]"])

        srv = FakeServer(h)
        try:
            pieces = []
            eng = CloudEngine("openai", "m1", "sk-testkey-123456", srv.url)
            out = eng.generate(MSGS, GEN, pieces.append)
        finally:
            srv.close()
        self.assertEqual(out, "Hello")
        self.assertEqual(pieces, ["Hel", "lo"])
        self.assertEqual(seen["auth"], "Bearer sk-testkey-123456")
        self.assertEqual(seen["body"]["messages"][0], {"role": "system", "content": "be nice"})

    def test_anthropic_stream_and_request_shape(self):
        seen = {}

        def h(req):
            seen["key"] = req.headers["x-api-key"]
            seen["ver"] = req.headers["anthropic-version"]
            seen["body"] = req.body
            sse(req, ["event: content_block_delta\ndata: " + json.dumps(
                      {"type": "content_block_delta", "delta": {"type": "text_delta", "text": "Hi"}}),
                      "event: message_stop\ndata: " + json.dumps({"type": "message_stop"})])

        srv = FakeServer(h)
        try:
            out = CloudEngine("anthropic", "claude-x", "ak-secret-123456", srv.url).generate(MSGS, GEN)
        finally:
            srv.close()
        self.assertEqual(out, "Hi")
        self.assertEqual(seen["key"], "ak-secret-123456")
        self.assertEqual(seen["body"]["system"], "be nice")
        self.assertTrue(all(m["role"] != "system" for m in seen["body"]["messages"]))

    def test_401_message_has_no_key(self):
        def h(req):
            req.send_response(401)
            req.end_headers()
            req.wfile.write(b'{"error":"bad key ak-secret-123456"}')

        srv = FakeServer(h)
        try:
            with self.assertRaises(CloudError) as ctx:
                CloudEngine("openai", "m", "ak-secret-123456", srv.url).generate(MSGS, GEN)
        finally:
            srv.close()
        self.assertNotIn("ak-secret", str(ctx.exception))
        self.assertIn("rejected", str(ctx.exception))

    def test_missing_key_and_model(self):
        with self.assertRaises(MissingKeyError):
            CloudEngine("openai", "m", "", "https://x.example").generate(MSGS, GEN)
        with self.assertRaises(CloudError):
            CloudEngine("openai", "", "k" * 12, "https://x.example").generate(MSGS, GEN)

    def test_https_enforced(self):
        check_url("https://api.example.com/v1")
        check_url("http://localhost:8080/x")
        with self.assertRaises(CloudError):
            check_url("http://api.example.com/v1")

    def test_cancel_stops_stream(self):
        def h(req):
            lines = ['data: ' + json.dumps({"choices": [{"delta": {"content": "a"}}]})] * 5
            sse(req, lines + ["data: [DONE]"])

        srv = FakeServer(h)
        cancel = threading.Event()
        got = []

        def tok(p):
            got.append(p)
            cancel.set()

        try:
            CloudEngine("openai", "m", "k" * 12, srv.url).generate(MSGS, GEN, tok, cancel)
        finally:
            srv.close()
        self.assertEqual(len(got), 1)


class FakeLlama:
    def __init__(self, path, n_ctx=0):
        self.path, self.n_ctx = path, n_ctx

    def create_chat_completion(self, messages, max_tokens, temperature, stream):
        self.last = messages
        for w in ["Hi", " there", "!"]:
            yield {"choices": [{"delta": {"content": w}}]}


class LocalTests(unittest.TestCase):
    def test_streams_with_fake_backend(self):
        import tempfile
        f = tempfile.NamedTemporaryFile(suffix=".gguf", delete=False)
        f.write(b"GGUF")
        f.close()
        eng = LocalEngine(f.name, backend_cls=FakeLlama)
        pieces = []
        out = eng.generate(MSGS, GEN, pieces.append)
        self.assertEqual(out, "Hi there!")
        self.assertEqual(eng._llm.last[0]["role"], "system")

    def test_missing_model_file(self):
        with self.assertRaises(EngineUnavailableError):
            LocalEngine("/nonexistent.gguf", backend_cls=FakeLlama).generate(MSGS, GEN)

    def test_no_backend_installed_is_clear_error(self):
        import tempfile
        f = tempfile.NamedTemporaryFile(suffix=".gguf", delete=False)
        f.close()
        with self.assertRaises(EngineUnavailableError) as ctx:
            LocalEngine(f.name).generate(MSGS, GEN)
        self.assertIn("backend", str(ctx.exception).lower())

    def test_extract_piece_variants(self):
        self.assertEqual(extract_piece({"choices": [{"text": "x"}]}), "x")
        self.assertEqual(extract_piece({"choices": [{"delta": {"role": "assistant"}}]}), "")
        self.assertEqual(extract_piece({}), "")


if __name__ == "__main__":
    unittest.main()
