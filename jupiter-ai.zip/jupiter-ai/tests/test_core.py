import os
import tempfile
import unittest

from jupiter.context import chars_budget, trim_messages
from jupiter.history import History
from jupiter.keystore import KeyStore
from jupiter.models import ChatMessage
from jupiter.redact import redact
from jupiter.settings import Settings, SettingsStore


class KeyStoreTests(unittest.TestCase):
    def setUp(self):
        self.d = tempfile.mkdtemp()
        os.environ.pop("JUPITER_OPENAI_API_KEY", None)

    def test_roundtrip_and_mask(self):
        ks = KeyStore(self.d)
        self.assertFalse(ks.has("openai"))
        ks.set("openai", "  sk-test-1234567890abcd ")
        self.assertEqual(ks.get("openai"), "sk-test-1234567890abcd")
        self.assertEqual(ks.masked("openai"), "...abcd")
        self.assertNotIn("sk-test", ks.masked("openai"))
        ks.delete("openai")
        self.assertIsNone(ks.get("openai"))

    def test_file_permissions(self):
        ks = KeyStore(self.d)
        ks.set("anthropic", "k" * 20)
        mode = os.stat(os.path.join(self.d, "keys.json")).st_mode & 0o777
        self.assertEqual(mode, 0o600)

    def test_env_override_and_validation(self):
        ks = KeyStore(self.d)
        os.environ["JUPITER_OPENAI_API_KEY"] = "envkey-123456"
        try:
            self.assertEqual(ks.get("openai"), "envkey-123456")
        finally:
            del os.environ["JUPITER_OPENAI_API_KEY"]
        with self.assertRaises(ValueError):
            ks.set("openai", "  ")
        with self.assertRaises(ValueError):
            ks.set("nope", "abc")


class SettingsTests(unittest.TestCase):
    def test_defaults_offline_and_no_key_fields(self):
        s = Settings()
        self.assertEqual(s.mode, "offline")
        self.assertFalse(any("key" in f.lower() for f in s.__dataclass_fields__))

    def test_save_load_clamps(self):
        d = tempfile.mkdtemp()
        st = SettingsStore(d)
        st.save(Settings(mode="bogus", max_tokens=10**6, temperature=9))
        s = st.load()
        self.assertEqual(s.mode, "offline")
        self.assertEqual(s.max_tokens, 8192)
        self.assertEqual(s.temperature, 2.0)

    def test_corrupt_file_gives_defaults(self):
        d = tempfile.mkdtemp()
        with open(os.path.join(d, "settings.json"), "w") as fh:
            fh.write("{not json")
        self.assertEqual(SettingsStore(d).load().mode, "offline")


class HistoryTests(unittest.TestCase):
    def test_conversation_lifecycle(self):
        h = History(tempfile.mkdtemp())
        c = h.new_conversation("t")
        h.add(c, "user", "hi")
        h.add(c, "assistant", "hello")
        self.assertEqual([m.role for m in h.messages(c)], ["user", "assistant"])
        self.assertIn("**You:**", h.export_markdown(c))
        h.delete_conversation(c)
        self.assertEqual(h.messages(c), [])
        h.new_conversation()
        h.clear_all()
        self.assertEqual(h.conversations(), [])


class ContextTests(unittest.TestCase):
    def test_keeps_newest_and_valid_order(self):
        msgs = [ChatMessage("user", "a" * 50), ChatMessage("assistant", "b" * 50),
                ChatMessage("user", "c" * 50)]
        out = trim_messages(msgs, 120)
        self.assertEqual(out[-1].content, "c" * 50)
        self.assertEqual(out[0].role, "user")

    def test_long_last_message_truncated(self):
        out = trim_messages([ChatMessage("user", "x" * 1000)], 100)
        self.assertEqual(len(out[0].content), 100)

    def test_budget_positive(self):
        self.assertGreaterEqual(chars_budget(512, 512), 512)


class RedactTests(unittest.TestCase):
    def test_redacts(self):
        text = "failed with sk-abcdefghijkl and Bearer abcdefghijk and secret999x"
        out = redact(text, ["secret999x"])
        for bad in ("sk-abcdefghijkl", "abcdefghijk", "secret999x"):
            self.assertNotIn(bad, out)


if __name__ == "__main__":
    unittest.main()
