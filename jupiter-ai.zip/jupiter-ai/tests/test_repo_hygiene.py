import re
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
PATTERNS = [re.compile(p) for p in (r"sk-[A-Za-z0-9]{20,}", r"AIza[0-9A-Za-z_\-]{30,}",
                                    r"gh[pousr]_[A-Za-z0-9]{30,}")]


class HygieneTests(unittest.TestCase):
    def test_no_secrets_in_source(self):
        for p in ROOT.rglob("*"):
            if p.is_file() and p.suffix in {".py", ".md", ".toml", ".yml", ".txt", ".json"}:
                if ".git" in p.parts:
                    continue
                text = p.read_text(encoding="utf-8", errors="ignore")
                for pat in PATTERNS:
                    self.assertIsNone(pat.search(text), "possible secret in %s" % p)

    def test_gitignore_covers_secret_files(self):
        gi = (ROOT / ".gitignore").read_text()
        for needle in ("keys.json", ".env", "*.gguf"):
            self.assertIn(needle, gi)


if __name__ == "__main__":
    unittest.main()
