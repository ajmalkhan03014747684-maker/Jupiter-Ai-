import json
import os
import tempfile
import unittest

from jupiter.assistant import Assistant
from jupiter.errors import CloudError, MissingKeyError
from jupiter.history import History
from jupiter.keystore import KeyStore
from jupiter.settings import Settings, SettingsStore


class FakeEngine:
    def __init__(self, text="ok", fail=None, partial=None):
        self.text, self.fail, self.partial, self.calls = text, fail, partial, 0

    def generate(self, msgs, gen, on_token=None, cancel=None):
        self.calls += 1
        if self.partial and on_token:
            on_token(self.partial)
        if self.fail:
            raise self.fail
        if on_token:
            on_token(self.text)
        return self.text


def make(settings, local=None, cloud=None, key=None):
    d = tempfile.mkdtemp()
    os.environ.pop("JUPITER_ANTHROPIC_API_KEY", None)
    ss, ks, h = SettingsStore(d), KeyStore(d), History(d)
    ss.save(settings)
    if key:
        ks.set(settings.provider, key)
    local = local or FakeEngine("local-answer")
    a = Assistant(h, ss, ks, lambda p, n: local, lambda *args: cloud or FakeEngine("cloud-answer"))
    return a, h, h.new_conversation()


class AssistantTests(unittest.TestCase):
    def test_offline_mode_needs_no_key_and_never_calls_cloud(self):
        cloud = FakeEngine()
        a, h, c = make(Settings(mode="offline"), cloud=cloud)
        r = a.reply(c, "hi")
        self.assertEqual((r.text, r.engine), ("local-answer", "local"))
        self.assertEqual(cloud.calls, 0)
        self.assertEqual([m.role for m in h.messages(c)], ["user", "assistant"])
        self.assertEqual(h.conversations()[0][1], "hi")

    def test_cloud_mode_with_key(self):
        a, _, c = make(Settings(mode="cloud"), key="k" * 20)
        r = a.reply(c, "hi")
        self.assertEqual((r.text, r.engine), ("cloud-answer", "cloud"))

    def test_cloud_without_key_falls_back_with_note(self):
        a, _, c = make(Settings(mode="cloud"))
        r = a.reply(c, "hi")
        self.assertEqual(r.engine, "local")
        self.assertIn("offline model", r.note)

    def test_cloud_without_key_no_fallback_raises(self):
        a, _, c = make(Settings(mode="cloud", fallback_to_offline=False))
        with self.assertRaises(MissingKeyError):
            a.reply(c, "hi")

    def test_cloud_error_falls_back(self):
        a, _, c = make(Settings(mode="cloud"), cloud=FakeEngine(fail=CloudError("boom")), key="k" * 20)
        r = a.reply(c, "hi")
        self.assertEqual((r.engine, r.text), ("local", "local-answer"))

    def test_midstream_failure_keeps_partial_no_duplicate(self):
        a, _, c = make(Settings(mode="cloud"),
                       cloud=FakeEngine(fail=CloudError("cut"), partial="part"), key="k" * 20)
        r = a.reply(c, "hi")
        self.assertEqual((r.text, r.engine), ("part", "cloud"))

    def test_key_never_written_to_settings_or_history(self):
        a, h, c = make(Settings(mode="cloud"), key="sk-SUPERSECRET-123456")
        a.reply(c, "hi")
        d = os.path.dirname(h._db)
        self.assertNotIn("SUPERSECRET", open(os.path.join(d, "settings.json")).read())
        self.assertNotIn("SUPERSECRET", json.dumps([m.content for m in h.messages(c)]))


if __name__ == "__main__":
    unittest.main()
