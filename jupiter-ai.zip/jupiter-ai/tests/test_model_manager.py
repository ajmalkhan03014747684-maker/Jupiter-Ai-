import os
import tempfile
import threading
import unittest

from jupiter.errors import Cancelled, DownloadError
from jupiter.model_manager import ModelSpec, download, installed_path, is_valid_gguf

from .helpers import FakeServer

DATA = b"GGUF" + bytes(range(256)) * 800  # ~200 KB


def spec(url, **kw):
    return ModelSpec("t", "t", url, "t.gguf", 1, "test", 1000, **kw)


def serve(data):
    def h(req):
        rng = req.headers.get("Range")
        start = int(rng.split("=")[1].rstrip("-")) if rng else 0
        chunk = data[start:]
        req.send_response(206 if rng else 200)
        req.send_header("Content-Length", str(len(chunk)))
        req.end_headers()
        req.wfile.write(chunk)
    return FakeServer(h)


class DownloadTests(unittest.TestCase):
    def test_full_download_and_progress(self):
        srv, d = serve(DATA), tempfile.mkdtemp()
        calls = []
        try:
            p = download(spec(srv.url + "/m"), d, lambda a, b: calls.append((a, b)))
        finally:
            srv.close()
        self.assertEqual(p.read_bytes(), DATA)
        self.assertEqual(calls[-1], (len(DATA), len(DATA)))
        self.assertIsNotNone(installed_path(spec("x"), d))
        self.assertFalse(os.path.exists(str(p) + ".part"))

    def test_resume_partial(self):
        srv, d = serve(DATA), tempfile.mkdtemp()
        with open(os.path.join(d, "t.gguf.part"), "wb") as fh:
            fh.write(DATA[:50000])
        try:
            p = download(spec(srv.url + "/m"), d)
        finally:
            srv.close()
        self.assertEqual(p.read_bytes(), DATA)

    def test_rejects_non_gguf(self):
        srv, d = serve(b"<html>" + b"x" * 5000), tempfile.mkdtemp()
        try:
            with self.assertRaises(DownloadError):
                download(spec(srv.url + "/m"), d)
        finally:
            srv.close()
        self.assertFalse(os.path.exists(os.path.join(d, "t.gguf")))

    def test_checksum_mismatch(self):
        srv, d = serve(DATA), tempfile.mkdtemp()
        try:
            with self.assertRaises(DownloadError):
                download(spec(srv.url + "/m", sha256="0" * 64), d)
        finally:
            srv.close()

    def test_cancel_keeps_part(self):
        srv, d = serve(DATA), tempfile.mkdtemp()
        ev = threading.Event()
        ev.set()
        try:
            with self.assertRaises(Cancelled):
                download(spec(srv.url + "/m"), d, cancel=ev)
        finally:
            srv.close()

    def test_validation_helper(self):
        d = tempfile.mkdtemp()
        p = os.path.join(d, "a")
        with open(p, "wb") as fh:
            fh.write(b"GGUF" + b"0" * 10)
        self.assertTrue(is_valid_gguf(p, 10))
        self.assertFalse(is_valid_gguf(p, 10**6))
        self.assertFalse(is_valid_gguf(p + "x"))


if __name__ == "__main__":
    unittest.main()
