"""Real-model smoke test: python scripts/smoke_local_model.py /path/model.gguf

Loads the GGUF through the same LocalEngine the app uses and generates a reply.
Run it in Termux/Pydroid/desktop, or via the 'Real model smoke test' workflow.
Exit code 0 only if a non-empty reply was produced.
"""
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from jupiter.engines.local import LocalEngine  # noqa: E402
from jupiter.models import ChatMessage, GenSettings  # noqa: E402


def main() -> int:
    if len(sys.argv) != 2:
        print(__doc__)
        return 2
    t0 = time.time()
    eng = LocalEngine(sys.argv[1], n_ctx=1024)
    out = eng.generate(
        [ChatMessage("user", "What is 2+2? Answer in one short sentence.")],
        GenSettings(max_tokens=40, temperature=0.1, system_prompt="You are concise."),
        on_token=lambda p: print(p, end="", flush=True),
    )
    print("\n--- backend=%s time=%.1fs chars=%d" % (eng.backend_name, time.time() - t0, len(out)))
    return 0 if out.strip() else 1


if __name__ == "__main__":
    raise SystemExit(main())
